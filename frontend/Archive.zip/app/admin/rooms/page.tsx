"use client";

import { useEffect, useState } from "react";
import { roomService } from "@/lib/services/roomService";
import { Room } from "@/types";
import RoomFormModal, { RoomFormValues } from "@/components/RoomFormModal";
import { getErrorMessage } from "@/lib/getErrorMessage";

function formatPrice(price: number) {
  return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(price);
}

export default function AdminRoomsPage() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | undefined>(undefined);
  const [submitting, setSubmitting] = useState(false);

const loadRooms = async () => {
  setLoading(true);
  setError("");

  try {
    const data = await roomService.getAllAdmin();
    setRooms(data);
  } catch (err) {
    setError(getErrorMessage(err));
  } finally {
    setLoading(false);
  }
};

useEffect(() => {
  let cancelled = false;

  const fetchRooms = async () => {
    setLoading(true);
    setError("");

    try {
      const data = await roomService.getAllAdmin();

      if (!cancelled) {
        setRooms(data);
      }
    } catch (err) {
      if (!cancelled) {
        setError(getErrorMessage(err));
      }
    } finally {
      if (!cancelled) {
        setLoading(false);
      }
    }
  };

  void fetchRooms();

  return () => {
    cancelled = true;
  };
}, []);

  const openCreate = () => {
    setEditingRoom(undefined);
    setModalOpen(true);
  };

  const openEdit = (room: Room) => {
    setEditingRoom(room);
    setModalOpen(true);
  };

  const handleSubmit = async (values: RoomFormValues) => {
    setSubmitting(true);
    try {
      if (editingRoom) {
        await roomService.update(editingRoom.id, values);
      } else {
        await roomService.create(values);
      }
      setModalOpen(false);
      await loadRooms();
    } catch (err) {
      alert(getErrorMessage(err, "Lưu phòng thất bại"));
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleActive = async (id: number) => {
    try {
      await roomService.toggleActive(id);
      loadRooms();
    } catch (err) {
      alert(getErrorMessage(err));
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Xóa phòng này? Hành động không thể hoàn tác.")) return;
    try {
      await roomService.remove(id);
      loadRooms();
    } catch (err) {
      alert(getErrorMessage(err, "Không thể xóa phòng (có thể đang có đơn đặt liên quan)"));
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-neutral-900">Quản lý phòng</h1>
        <button
          onClick={openCreate}
          className="rounded-full bg-rose-600 px-4 py-2 text-sm font-medium text-white hover:bg-rose-700"
        >
          + Thêm phòng
        </button>
      </div>

      {loading && <p className="mt-6 text-neutral-500">Đang tải...</p>}
      {error && <p className="mt-6 text-red-600">{error}</p>}

      <div className="mt-6 overflow-x-auto rounded-2xl border border-neutral-200">
        <table className="w-full text-left text-sm">
          <thead className="bg-neutral-50 text-neutral-500">
            <tr>
              <th className="px-4 py-3">Tên phòng</th>
              <th className="px-4 py-3">Giá/đêm</th>
              <th className="px-4 py-3">Khách tối đa</th>
              <th className="px-4 py-3">Trạng thái</th>
              <th className="px-4 py-3 text-right">Hành động</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100">
            {rooms.map((room) => (
              <tr key={room.id}>
                <td className="px-4 py-3 font-medium text-neutral-900">{room.name}</td>
                <td className="px-4 py-3">{formatPrice(room.pricePerNight)}</td>
                <td className="px-4 py-3">{room.maxGuests}</td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => handleToggleActive(room.id)}
                    className={`rounded-full px-3 py-1 text-xs font-medium ${
                      room.active ? "bg-green-100 text-green-700" : "bg-neutral-100 text-neutral-500"
                    }`}
                  >
                    {room.active ? "Đang hoạt động" : "Đã ẩn"}
                  </button>
                </td>
                <td className="px-4 py-3 text-right">
                  <button
                    onClick={() => openEdit(room)}
                    className="mr-3 text-neutral-600 hover:text-rose-600"
                  >
                    Sửa
                  </button>
                  <button onClick={() => handleDelete(room.id)} className="text-red-600 hover:text-red-800">
                    Xóa
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modalOpen && (
        <RoomFormModal
          initial={editingRoom}
          onClose={() => setModalOpen(false)}
          onSubmit={handleSubmit}
          submitting={submitting}
        />
      )}
    </div>
  );
}